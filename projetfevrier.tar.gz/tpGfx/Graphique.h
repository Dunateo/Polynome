void affichageTableau(tableauvar Premier);
void affichagePoint(zero PointP, tableauvar Premier);
void affichageGraphique(tableauvar Premier);
