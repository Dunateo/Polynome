/* Veuillez reporter tout commentaire a ghislain.oudinet@isen.fr */

#ifndef ERREURLIB_H
#define ERREURLIB_H

extern const char *ChaineErreurLisEntier;
extern const char *ChaineErreurLisFlottant;
extern const char *ChaineErreurLisCaractere;

#endif
