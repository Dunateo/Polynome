#include <stdlib.h> // Pour pouvoir utiliser exit()
#include <stdio.h> // Pour pouvoir utiliser printf()
#include <math.h> // Pour pouvoir utiliser sin() et cos()
#include <string.h>
#include "GfxLib.h" // Seul cet include est necessaire pour faire du graphique
#include "CalculPolynome.h"

void affichageGraphique(tableauvar Premier){
  couleurCourante(50,50,50);
  epaisseurDeTrait(3);
  ligne((0+(0-Premier.polynome.a)*largeurFenetre())/(Premier.polynome.b-Premier.polynome.a),hauteurFenetre()/2,(0+(0-Premier.polynome.a)*largeurFenetre())/(Premier.polynome.b-Premier.polynome.a),hauteurFenetre());
  ligne(0,hauteurFenetre()/2+(0-Premier.polynome.c)*((hauteurFenetre()/2))/(Premier.polynome.d-Premier.polynome.c),largeurFenetre(),hauteurFenetre()/2+(0-Premier.polynome.c)*(hauteurFenetre()/2)/(Premier.polynome.d-Premier.polynome.c));

}
void affichagePoint(zero PointP, tableauvar Premier){
  pointt x1, x2;
  for(int i=0; i< PointP.nbpt; i++) {
    x1.x = 0+(PointP.Z[i].x-Premier.polynome.a)*largeurFenetre()/(Premier.polynome.b-Premier.polynome.a);
    x1.y = (hauteurFenetre()/2)+(PointP.Z[i].y-Premier.polynome.c)*(hauteurFenetre()-hauteurFenetre()/2)/(Premier.polynome.d-Premier.polynome.c);
    x2.x = 0+(PointP.Z[i+1].x-Premier.polynome.a)*largeurFenetre()/(Premier.polynome.b-Premier.polynome.a);
    x2.y = (hauteurFenetre()/2)+(PointP.Z[i+1].y-Premier.polynome.c)*(hauteurFenetre()-hauteurFenetre()/2)/(Premier.polynome.d-Premier.polynome.c);
    printf("%f  %f\n", x1.x,x1.y);
    printf("c'est la 2 %f  %f\n", x2.x,x2.y);
    couleurCourante(255,0,0);
    epaisseurDeTrait(2);
    ligne(x1.x,x1.y,x2.x,x2.y);
  }
}

void affichageTableau(tableauvar Premier){
  char nb[5];
  char nb1[5];
  char nb3[5];
  float nt = 3/Premier.D.nbpt;
  float maj;
  couleurCourante(50,50,50);
  rectangle(0,0,largeurFenetre(),hauteurFenetre()/2);
  couleurCourante(255,255,255);
  rectangle(largeurFenetre()/6,0,largeurFenetre(),hauteurFenetre()/3);
  epaisseurDeTrait(3);
  afficheChaine("x", 20, largeurFenetre()/9, 7*hauteurFenetre()/19);
  afficheChaine("p'(x)", 20, largeurFenetre()/9, 5*hauteurFenetre()/19);
  afficheChaine("p(x)", 20, largeurFenetre()/9, 2*hauteurFenetre()/19);
  ligne(0,4*hauteurFenetre()/19,largeurFenetre(),4*hauteurFenetre());
  sprintf(nb, "%.2f", Premier.polynome.a);
  afficheChaine(nb, 20, 2*largeurFenetre()/9, 7*hauteurFenetre()/19);
  sprintf(nb1, "%.2f", Premier.polynome.b);
  afficheChaine(nb1, 20, 8*largeurFenetre()/9, 7*hauteurFenetre()/19);

  for (int i = 0; i < Premier.D.nbpt; i++) {
    sprintf(nb3, "%.2f", Premier.D.Z[i].x);
    maj = 2+nt;
    afficheChaine(nb3, 20, (maj)*largeurFenetre()/9, 7*hauteurFenetre()/19);
    couleurCourante(50,50,50);
    afficheChaine("0", 20, (maj)*largeurFenetre()/9, 5*hauteurFenetre()/19);

    nt = maj;
  }

  for (int i = 0; i < Premier.D.nbpt+1; i++) {
    maj = 2+nt;
    if(Premier.variation.forme == 1){
      couleurCourante(50,50,50);
      afficheChaine("+", 30, (maj-nt)*largeurFenetre()/9, 5*hauteurFenetre()/19);
    }
    if(Premier.variation.forme == 0){
      couleurCourante(50,50,50);
      afficheChaine("-",30, (maj-nt)*largeurFenetre()/9, 5*hauteurFenetre()/19);
    }
  if(Premier.variation.forme == 2){
    couleurCourante(50,50,50);
    afficheChaine("M", 20, 3*largeurFenetre()/9, 7*hauteurFenetre()/19);
  }
    nt = maj;

}

for (int i = 0; i < Premier.D.nbpt+1; i++) {
  maj = 2+nt;
  if(Premier.variation.forme == 1){
    couleurCourante(50,50,50);

  }
  if(Premier.variation.forme == 0){
    couleurCourante(50,50,50);
    afficheChaine("-",30, (maj-nt)*largeurFenetre()/9, 5*hauteurFenetre()/19);
  }
if(Premier.variation.forme == 2){
  couleurCourante(50,50,50);
  afficheChaine("M", 20, 3*largeurFenetre()/9, 7*hauteurFenetre()/19);
}
  nt = maj;
  Premier.variation.forme = 1-Premier.variation.forme;
}
}
